<?php
	include 'conexao.php';
	session_start();
	if (empty($_SESSION["login"])) {
		echo "<script>alert('Faça o login primeiramente!')
		window.location.href = 'login.php';
		</script>";
		
	}
	if($_POST){
		if (isset($_FILES["imgProduto"])) {
			date_default_timezone_get();
			$ext = strtolower(substr($_FILES['imgProduto']['name'],-4));
			$newName = date("Y.m.d-H.i.s").$ext;
			$dir = 'images/produtos/';
			move_uploaded_file($_FILES['imgProduto']['tmp_name'], $dir.$newName);
		}
		$nome = $_POST["nome"];
		$descricao = $_POST["descricao"];
		$custo = $_POST["custo"];
		$venda = $_POST["venda"];
		$porcLucro = (($venda-$custo)/$venda)*100;
		$imagem = $newName;
		$categoria = $_POST["categoria"];
		$sql = "INSERT INTO produto VALUES ('$nome','$descricao','$custo','$venda','$porcLucro','$imagem','$categoria')";
		if (mysqli_query($conexao,$sql)) {
			echo "<script>alert('CADASTRO REALIZADO COM SUCESSO!')</script>";
		}else{
			echo "FALHA NO CADASTRO!".mysqli_error($conexao);
		}
	}
	
?>

<!DOCTYPE html>
<html lang="pt-br" style="background-color: #131a20;">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
		<link rel="shortcut icon" href="images/logo.png" type="images/logo.png"/>
		<title>Evolution Market</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file -->
		<link rel="stylesheet" href="style.css">
		<!-- TESTE Crop
		<link rel="stylesheet" href="css/croppie.css"> -->

		
	</head>


	<body>

		<div id="site-content">
			<!-- header com infos e navbar -->
			<?php include 'header.php';?>

			<main class="main-content">
				<div class="container">
					<div class="breadcrumbs">
							<a href="index.php">Home</a>
							<span>Cadastro de Produtos</span>
					</div>
					<form action="" method="POST" enctype="multipart/form-data">
						<h1>Cadastrar Produto</h1>
							<label> Nome do produto:</label>
							<input type="text" name="nome" placeholder="Aplicação"/><br><br>
							<div class="form-group">
								<label for="exampleFormControlTextarea1">Descrição: </label>
							    <textarea class="form-control" name="descricao" rows="3"></textarea><br><br>
							 </div>
							<label> Preço de Custo:</label>
							<input type="number" name="custo" placeholder="1200.00"/><br><br>
							<label> Preço de Venda:</label>
							<input type="number" name="venda" placeholder="1500.00"/><br><br>
							<label> Imagem miniatura do produto: </label>
							<input type="file" name="imgProduto"><br><br>

							<!-- Listagem das categorias -->
							<label> Categoria:</label>
							<select name= "categoria">
								<?php
								$sql2="SELECT * FROM categorias";
								$resultado= mysqli_query($conexao,$sql2);
									if (mysqli_num_rows($resultado) > 0){
										while ($row = mysqli_fetch_assoc($resultado)) {
											$nomeCategoria = $row["nome"];
										echo
										"<option value='".$nomeCategoria."'>".$nomeCategoria."</option>";
										}
									}else{
										echo "<option value=''>	Nenhuma categoria cadastrada </option> ";
									}
								?>
							</select><br><br>
							<input type= "submit" value="CADASTRAR">
					</form>
				</div>
			</main>
			<br><br><br><br><br><br>
			<?php include 'footer.php'?>
			
		</div>
		<!-- Default snippet for navigation -->
		
		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
		<!--<script src="js/croppie.js"></script>-->
		
	</body>

</html>