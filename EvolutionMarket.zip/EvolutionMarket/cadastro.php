<?php
	include 'conexao.php';

	if (isset($_POST["login"]) && isset($_POST["senha"])) {
		$login = $_POST["login"];
		$senha = md5($_POST["senha"]);

		$sql = "SELECT * FROM usuarios WHERE login LIKE '$login'";
		$resultado = mysqli_query($conexao, $sql);

		if(mysqli_num_rows($resultado) == 1){
			echo "<script>alert('Login já existe. Tente outro!')</script>";
		}
		else{
			$sql = "INSERT INTO usuarios VALUES(null,'$login', '$senha')";
			if (mysqli_query($conexao, $sql)) {
				echo "<script>alert('Cadastro realizado com sucesso!');
				window.location.href = 'login.php'; </script>";
			}
			else{
				"<script>alert('Falha ao cadastrar');</script>";
			}
		}

	}
?>

<!DOCTYPE html>
<html lang="pt-br" style="background-color: #131a20;">
	<head>
		<title>Evolution Market | Cadastro</title>
		<!-- Meta tags Obrigatórias -->
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Arquivo CSS Bootstrap -->
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<!-- Arquivo CSS do projeto -->
		<link rel="stylesheet" href="css/estilo.css" />
		<link rel="stylesheet" href="style.css" />
		<!-- CSS interno -->
		<link rel="shortcut icon" href="images/logo.png" type="images/logo.png"/>
		<link rel="shortcut icon" href="images/logo.png" type="images/logo.png"/>	
	</head>
	<body>
	<center>
		<div class="container" style="padding-top: 200px;">
			<form class="form-signin" action="" method="post">
	      	  <h1 class="h3 font-weight-normal mb-5" style="color: white;"}>Cadastre-se!</h1>
			  <input type="text" name="login" id="inputLogin" class="form-control mb-2" placeholder="Nome de usuário" required autofocus>
			  <input type="password" name="senha" id="inputPassword" class="form-control" placeholder="Senha" required>
			  
			  <button class="btn btn-lg btn-primary btn-block" type="submit">Cadastrar</button>
			  <div class="semcadastro">
				<p>Já tem cadastro? <a href="login.php"> Acesse sua conta!</a></p>
			  </div>
			</form>
		</div><!-- fim class container -->
	</center>
	<!-- documentos javascript -->
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/popper.min.js"></script>
	</body>
</html>