<?php
include 'conexao.php';
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br" style="background-color: #131a20;">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
		<link rel="shortcut icon" href="images/logo.png" type="images/logo.png"/>
		<title>Evolution Market</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file -->
		<link rel="stylesheet" href="style.css">


	</head>


	<body>
		<div id="site-content">
			<?php include 'header.php';?>

			<main class="main-content">
				<div class="container">
					<div class="page">
						<div class="breadcrumbs">
							<a href="index.php">Home</a>
							<span>Nossos Produtos</span>
						</div>
						<!-- LISTAGEM DOS PRODUTOS -->
						<div class="movie-list">
							<?php
							$sql="SELECT * FROM produto";
							$resultado= mysqli_query($conexao,$sql);
								if (mysqli_num_rows($resultado) > 0)
								{
								while ($row = mysqli_fetch_assoc($resultado)) 
								{
								echo
								"<div class='movie'>".
									"<figure class='movie-poster'><img src='images/produtos/".$row["imagem"]."' alt='".$row["nome"]."' style='height: 240px; width: 330px;''></figure>".
									"<div class='movie-title'><a href='#'>".$row["categoria"]."</a> - ".$row["nome"]."</div>".
									"<p>".$row["descricao"]."</p>".
									"<p>Preço: R$".$row["precoVenda"].",00</p>".
								"</div>";
								}
								}else{
									echo "Nenhum produto cadastrado";
								}
							?>
							
						</div> <!-- .movie-list -->

						<div class="pagination">
							<a href="#" class="page-number prev"><i class="fa fa-angle-left"></i></a>
							<span class="page-number current">1</span>
							<a href="#" class="page-number">2</a>
							<a href="#" class="page-number">3</a>
							<a href="#" class="page-number">4</a>
							<a href="#" class="page-number">5</a>
							<a href="#" class="page-number next"><i class="fa fa-angle-right"></i></a>
						</div>
					</div>
				</div> <!-- .container -->
			</main>

			<?php include 'footer.php'?>
			
		</div>
		<!-- Default snippet for navigation -->
		


		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
		
	</body>

</html>