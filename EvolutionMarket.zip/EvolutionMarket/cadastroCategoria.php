<?php
	include 'conexao.php';
	session_start();
	if (empty($_SESSION["login"])) {
		echo "<script>alert('Faça o login primeiramente!')
		window.location.href = 'login.php';
		</script>";
		
	}
	if($_POST){
		if (isset($_FILES["imgCategoria"])) {
			date_default_timezone_get();
			$ext = strtolower(substr($_FILES['imgCategoria']['name'],-4));
			$newName = date("Y.m.d-H.i.s").$ext;
			$dir = 'images/categorias/';
			move_uploaded_file($_FILES['imgCategoria']['tmp_name'], $dir.$newName);
		}
		$nome = $_POST["nome"];
		$imagem = $newName;
		$sql = "INSERT INTO categorias VALUES ('$nome','$imagem')";
		if (mysqli_query($conexao,$sql)) {
			echo "<script>alert('CADASTRO REALIZADO COM SUCESSO!')</script>";
		}else{
			echo "FALHA NO CADASTRO!".mysqli_error($conexao);
		}
	}
?>

<!DOCTYPE html>
<html lang="pt-br" style="background-color: #131a20;">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
		<link rel="shortcut icon" href="images/logo.png" type="images/logo.png"/>
		<title>Evolution Market</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file -->
		<link rel="stylesheet" href="style.css">
		<!-- Teste CROP
		<link rel="stylesheet" href="css/croppie.css">

		<script>
			$uploadCrop = $('#imgCategoria').croppie({
			    enableExif: true,
			    viewport: {
			        width: 200,
			        height: 200,
			        type: 'circle'
			    },
			    boundary: {
			        width: 300,
			        height: 300
			    }
			});
		</script> -->
	</head>


	<body>

		<div id="site-content">
			<!-- header com infos e navbar -->
			<?php include 'header.php';?>

			<main class="main-content">
				<div class="container">
					<div class="breadcrumbs">
							<a href="index.php">Home</a>
							<span>Cadastro de Categoria</span>
					</div>
					<form action="" method="POST" enctype="multipart/form-data">
						<h1>Cadastrar Categoria</h1>
							<label> Nome da categoria:</label>
							<input type="text" name="nome" placeholder="E-Commerce"/><br><br>
							<label>Imagem miniatura da categoria: </label>
							<input type="file" name="imgCategoria" value="Inserir imagem"><br><br>

							<input type= "submit" value="CADASTRAR">
					</form>
				</div>
			</main>
			<br><br><br><br><br><br>
			<?php include 'footer.php'?>
			
		</div>
		<!-- Default snippet for navigation -->
		
		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
		<!--<script src="js/croppie.js"></script>-->

	</body>

</html>