<header class="site-header">
	<div class="container">
		<a href="index.php" id="branding">
			<img src="images/logo.png" alt="Evolution Market" class="logo" width="32" height="32">
			<div class="logo-copy">
				<h1 class="site-title">Evolution Market</h1>
				<small class="site-description">Seja bem-vindo <b><?= $_SESSION["login"] ?></b>!</small>
			</div>
		</a> <!-- #branding -->

		<div class="main-navigation">
			<button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
			<ul class="menu">
				<li class="menu-item"><a href="index.php">Home</a></li>
				<li class="menu-item"><a href="listagemProduto.php">Nossos Produtos</a></li>
				<li class="menu-item"><a href="cadastroCategoria.php">Cadastro de Categoria</a></li>
				<li class="menu-item"><a href="cadastroProduto.php">Cadastro de Produto</a></li>
				<li class="menu-item"><a href="logout.php">Sair</a>
			</ul> <!-- .menu -->
			</form>
			</div> <!-- .main-navigation -->
		<div class="mobile-navigation"></div>
	</div>
</header>