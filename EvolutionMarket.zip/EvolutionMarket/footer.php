<footer class="site-footer">
				<div class="container">
					<div class="row">
						<div class="col-md-4">
							<div class="widget">
								<h3 class="widget-title">Sobre nós</h3>
								<p>A Evloution market busca trazer os melhores prodtos da atualidade para que você só utilize do melhor que a internet tem à oferecer.</p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="widget">
								<h3 class="widget-title">Market</h3>
								<ul class="no-bullet">
									<li><a href="#">Equipe de desenvolvimento</a></li>
									<li><a href="#">Produtos</a></li>
									<li><a href="#">Fale conosco</a></li>
									<li><a href="#">Sugestões</a></li>
								</ul>
							</div>
						</div>
						<div class="col-md-4">
							<div class="widget">
								<h3 class="widget-title">Redes Sociais</h3>
								<ul class="no-bullet">
									<li><a href="#">Facebook</a></li>
									<li><a href="#">Twitter</a></li>
								</ul>
							</div>
						</div>
					</div> <!-- .row -->

					<div class="colophon">Todos os direitos reservados © Evolution Market 2020</div>
				</div> <!-- .container -->

			</footer>
		