<?php
	session_start();
	if (empty($_SESSION["login"])) {
		echo "<script>alert('Faça o login primeiramente!')
		window.location.href = 'login.php';
		</script>";
		
	}
?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
		<link rel="shortcut icon" href="images/logo.png" type="images/logo.png"/>
		<title>Evolution Market</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file -->
		<link rel="stylesheet" href="style.css">

	</head>


	<body>
		

		<div id="site-content">
			<!-- header com infos e navbar -->
			<?php include 'header.php';?>

			<main class="main-content">
				<div class="container">
					<div class="page">
						<div class="row">
							<div class="col-md-9">
								<div class="slider">
									<ul class="slides">
										<li><a href="#"><img title="Propaganda/Promoção" style="height: 518px;" src="dummy/propaganda8.jpg" alt="Slide 1" width="870"></a></li>
										<li><a href="#"><img title="Propaganda/Promoção" style="height: 518px;" src="dummy/propaganda9.jpg" alt="Slide 2" width="870"></a></li>
										<li><a href="#"><img title="Propaganda/Promoção" style="height: 518px;" src="dummy/propaganda1.jpg" alt="Slide 3" width="870"></a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-3">
								<div class="row">
									<div class="col-sm-6 col-md-12">
										<div class="latest-movie">
											<a href="#"><img title="Propaganda/Promoção" src="dummy/propaganda4.jpg" alt="Propaganda"></a>
										</div>
									</div>
									<div class="col-sm-6 col-md-12">
										<div class="latest-movie">
											<a href="#"><img title="Propaganda/Promoção" src="dummy/propaganda5.jpg" alt="Propaganda"></a>
										</div>
									</div>
								</div>
							</div>
						</div> <!-- .row -->
						<div class="row">
							<div class="col-sm-6 col-md-3">
								<div class="latest-movie">
									<a href="#"><img title="Propaganda/Promoção" src="dummy/propaganda6.jpg" alt="Propaganda"></a>
								</div>
							</div>
							<div class="col-sm-6 col-md-3">
								<div class="latest-movie">
									<a href="#"><img title="Propaganda/Promoção" src="dummy/propaganda7.jpg" alt="Propaganda"></a>
								</div>
							</div>
							<div class="col-sm-6 col-md-3">
								<div class="latest-movie">
									<a href="#"><img title="Propaganda/Promoção" src="dummy/propaganda2.jpg" alt="Propaganda"></a>
								</div>
							</div>
							<div class="col-sm-6 col-md-3">
								<div class="latest-movie">
									<a href="#"><img title="Propaganda/Promoção" src="dummy/propaganda1.jpg" alt="Propaganda"></a>
								</div>
							</div>
						</div> <!-- .row -->
					</div>
				</div> <!-- .container -->
			</main>
			<br><br><br><br><br><br>
			<?php include 'footer.php'?>
			
		</div>
		<!-- Default snippet for navigation -->
		


		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
		
	</body>

</html>